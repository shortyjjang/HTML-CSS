<script setup>
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup
import Header from './components/layouts/Header.vue'
</script>

<template>
  <Header msg="Hello Vue 3 + Vite" />
  <div id="container-wrapper">
    <router-view></router-view>
  </div>
</template>

<style>
</style>
