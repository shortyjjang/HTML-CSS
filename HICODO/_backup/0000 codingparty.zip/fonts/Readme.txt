﻿Fonts folder contains custom font files for your application.
